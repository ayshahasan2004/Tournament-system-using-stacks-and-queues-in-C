#include <stdio.h>
#include <stdlib.h>
//////Aysha mohamad
//////1220352
///////Dr. radi    10:00AM
struct stack;
struct queue;

typedef struct stack* pts;
typedef struct queue* ptq;

struct stack {
    int team_id;
    pts next;
};

struct queue {
    int team_id;
    ptq next;
    ptq front;
    ptq rear;
};
int determine_winner_odd(int team1, int team2);  // Determine winner in odd rounds (smaller ID wins)
int determine_winner_even(int team1, int team2); // Determine winner in even rounds (larger ID wins)
int determine_winner_of_two_teams(int team1, int team2, int round); // Determine winner of two teams based on round number
int champion(ptq teamQueue, ptq all_losers, pts stack); // Simulate the tournament and determine the champion
int runner_up(int champion, int* ids, int n, pts stack); // Find the runner-up by checking which teams lost to the champion
ptq createQueue();                               // Create and initialize a new queue
void enqueue(ptq q, int team_id);                // Enqueue a team at the back of the queue
int dequeue(ptq q);                              // Dequeue a team from the front of the queue
void enqueue_front(ptq q, int team_id);          // Enqueue a team at the front of the queue
void push(pts S, int team);                      // Push a team onto the stack
pts pop(pts S);                                  // Pop a team from the stack
pts createStack();                               // create and initialize a new stack


// Function to push node to stack
void push(pts S, int team) {
    if (S == NULL) {
        printf("Stack is not found..\n");
    } else {
        pts k = (pts)malloc(sizeof(struct stack));
        k->team_id = team;
        k->next = S->next;
        S->next = k;
    }
}
/////////////////////////////////////////////////////////////////////////
// Function to pop node from stack
pts pop(pts S) {
    if (S == NULL) {
        printf("Stack is not found..\n");
        return NULL;
    } else {
        if (S->next != NULL) {
            pts temp = S->next;
            S->next = temp->next;
            temp->next = NULL;
            return temp;
        } else return NULL;
    }
}
//////////////////////////////////////////////////////////////////////////
// Function to create stack
pts createStack() {
    pts T = (pts)malloc(sizeof(struct stack));
    if (T == NULL) {
        printf("Stack can not be defined..\n");
        return NULL;
    } else {
        T->next = NULL;
        return T;
    }
}
/////////////////////////////////////////////////////////////////////////
// Function to create Queue
ptq createQueue() {
    ptq T = (ptq)malloc(sizeof(struct queue));
    if (T == NULL) {
        printf("Queue can not be defined..\n");
        return NULL;
    } else {
        T->next = NULL;
        T->front = T->next;
        T->rear = T->next;
        return T;
    }
}

// Function to enqueue a team to the back of the queue
void enqueue(ptq q, int team_id) {
    ptq new_node = (ptq)malloc(sizeof(struct queue));
    new_node->team_id = team_id;
    new_node->next = NULL;

    ptq temp = q;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = new_node;
}
////////////////////////////////////////////////////////////////////////
// Function to dequeue a team from the front of the queue
int dequeue(ptq q) {
    if (q->next == NULL) return -1; // Queue is empty
    ptq temp = q->next;
    int team_id = temp->team_id;
    q->next = temp->next;
    free(temp);
    return team_id;
}
///////////////////////////////////////////////////////////////////////////
// Function to enqueue a team to the front of the queue (push operation)
void enqueue_front(ptq q, int team_id) {
    ptq new_node = (ptq)malloc(sizeof(struct queue));
    new_node->team_id = team_id;
    new_node->next = q->next;
    q->next = new_node;
}
/////////////////////////////////////////////////////////////////////////////
// Function to determine the winner in odd rounds (smaller ID win)
int determine_winner_odd(int team1, int team2) {
    return (team1 < team2) ? team1 : team2; // Smaller ID wins
}

// Function to determine the winner in even rounds (larger ID win)
int determine_winner_even(int team1, int team2) {
    return (team1 > team2) ? team1 : team2; // Larger ID wins
}

// Function to determine the winner of a match based on the round
int determine_winner_of_two_teams(int team1, int team2, int round) {
    if (round % 2 == 1) {
        return determine_winner_odd(team1, team2); // Use odd round logic
    } else {
        return determine_winner_even(team1, team2); // Use even round logic
    }
}

//////////////////////////////////////////////////////////////////////////////////////////////
int champion(ptq teamQueue, ptq all_losers, pts stack) {
    int round = 1;
    int champion = -1; /////////////////initial value

    // While there are at least two teams in the tournament
    while (teamQueue->next != NULL && teamQueue->next->next != NULL) {
        ptq next_round = createQueue();
        printf("\nRound %d:\n", round);

        // Process the current round
        while (teamQueue->next != NULL && teamQueue->next->next != NULL) {
            int team1 = dequeue(teamQueue);
            int team2 = dequeue(teamQueue);
            int winner = determine_winner_of_two_teams(team1, team2, round);
            int loser = (winner == team1) ? team2 : team1;

            // Track the loser for later ranking in the stack
            push(stack, loser);
            enqueue(all_losers, loser);

            // Print match result
            printf("Match: %d vs %d   Winner: %d (Round %d: %s ID wins)\n",
                   team1, team2, winner, round,
                   (round % 2 == 1) ? "smaller" : "larger");

            // Move the winner to the next round
            enqueue(next_round, winner);
        }

        // If there's an odd number of teams, the last one automatically advances
        if (teamQueue->next != NULL) {
            int last_team = dequeue(teamQueue);
            printf("Team %d automatically qualifies to the next round.\n", last_team);
            enqueue_front(next_round, last_team);
        }

        // move to the next round
        teamQueue = next_round;
        round++;
    }

    //  remaining team is the champion
    champion = teamQueue->next->team_id;
    printf("\nThe Champion: %d\n", champion);

    return champion;
}
///////////////////////////////////////////////////////////////////////////////////////////
int runner_up(int champion, int* ids, int n, pts stack) {
    // create a new stack to reverse the order of the losers
    pts newstack = createStack();

    //////////printf("finding the runner-up by checke which teams lost to the champion.\n");

    // loop for the team ids and check which team lost to the champion
    for (int i = 0; i < n - 1; i++) {  // Adjust the loop to avoid out-of-bounds error
        //////////printf("Checking match between team %d and team %d\n", ids[i], ids[i + 1]);

        if (ids[i] == champion || ids[i + 1] == champion) {
            ///////// add the loser of this match to the stack
            int loser = (ids[i] == champion) ? ids[i + 1] : ids[i];
            ////////////////printf("Team %d lost to the champion %d and is added to the stack.\n", loser, champion);
            push(stack, loser);
        }
    }

    // reverse the stack by pushing the elements into a new stack
    //////////printf("\nReversing the order of the stack...\n");
    while (stack->next != NULL) {
        pts temp = pop(stack);
        ///////////printf("Popped team %d from the stack and pushed it to the new stack.\n", temp->team_id);
        push(newstack, temp->team_id); // Push the team ID to the new stack
        free(temp);  // Free the popped item to avoid memory leak
    }

    // The runner-up is the last team in the new stack
   /////////////// printf("\nThe runner-up is the last team in the new stack...\n");
    pts temp = pop(newstack);
    int runner_up_team = temp->team_id;
    printf("The runner-up team is %d.\n", runner_up_team);
    free(temp);  // Free the popped item

    // return the runner-up team ID
    return runner_up_team;
}

///////////////////////////////////////////////////////////////
int main() {
    while (1) {
        int num_teams;

        printf("\nEnter number of teams followed by the team IDs :\n");

        int* ids = (int*)malloc(10000 * sizeof(int)); // Allocate enough space for IDs
        if (ids == NULL) {
            printf("Memory allocation failed.\n");
            exit(1);
        }

        if (scanf("%d", &num_teams) != 1 || num_teams <= 1 || num_teams >= 10000) {
            printf("Invalid number of teams. It must be between 2 and 9999.\n");
            break;
            exit(0);
        }

        // validate the number of teams
        if (num_teams <= 1 || num_teams >= 10000) {
            printf("Invalid number of teams. It must be between 2 and 9999.\n");
            continue;
        }

        // read the team ids
        printf("enter the team ids: ");
        for (int i = 0; i < num_teams; i++) {
            if (scanf("%d", &ids[i]) != 1 || ids[i] <= -10000 || ids[i] >= 10000) {
                printf("Invalid team ID. Team ID must be between -9999 and 9999.\n");
                i--;  // Decrement i to re-enter this id
                continue;
            }
        }

        ptq teamQueue = createQueue();
        ptq all_losers = createQueue();
        pts stack = createStack();  // Stack to hold runner-ups

        // enqueue the team ids into the queue
        for (int i = 0; i < num_teams; i++) {
            enqueue(teamQueue, ids[i]);
        }

        int champion1 = champion(teamQueue, all_losers, stack);
        pts S = createStack();
        int runner_up_team = runner_up(champion1, ids, num_teams, S);
        printf("champion: %d\n", champion1);
        printf("runner-up: %d\n", runner_up_team);
        free(ids);
        free(all_losers);
        free(teamQueue);
        free(S);
    }

    return 0;
}
